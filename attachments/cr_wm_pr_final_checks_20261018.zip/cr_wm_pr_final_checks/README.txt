CR-WM submission checks

This attachment retains the checks supporting the submitted adapter:

- archive_identity.json: current SHA256 identities for all 143 policy files.
- equivalence_to_tested_package.json: code-equivalence evidence linking the packaged source to the preserved, actually tested LF-repaired code archive.
- final_static_checks.json: recorded shell/Python syntax, image handling, required-file/method, vendored-source and strict-asset checks.
- git_diff_check.log: recorded isolated all-new-addition Git whitespace checks.
- SHA256SUMS: current checksums for the files in this attachment.

The equivalence and static reports describe the preceding formatting-clean candidate. Its executable source, configuration and resource bytes remain unchanged; later policy changes are limited to README wording and user-supplied Markdown/XLSX results reports. The report task counts and success rates match the preserved native benchmark evidence. archive_identity.json identifies the current policy files, including the README and updated results reports. Historical report identities must not be interpreted as a later model execution or current documentation hashes.

The separate cr_wm_pr_test_evidence_20261018.zip retains all actual interface transcripts, command/timing records, simulator results, native benchmark summaries, original/public hash bindings and the explicit redaction notice. Those files were not changed by this attachment cleanup.

No training or evaluation code was changed, and no new model run is claimed.
